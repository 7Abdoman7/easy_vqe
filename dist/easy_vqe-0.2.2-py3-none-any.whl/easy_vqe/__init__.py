"""
Easy VQE Package
----------------

A simple interface for running Variational Quantum Eigensolver (VQE)
simulations using Qiskit, focusing on ease of use for defining Hamiltonians
and ansatz structures.
"""
from easy_vqe import find_ground_state
from easy_vqe import draw_final_bound_circuit, print_results_summary, get_theoretical_ground_state_energy
from easy_vqe import create_custom_ansatz, parse_hamiltonian_expression


__version__ = "0.2.2" 

__all__ = [
    'find_ground_state',
    'create_custom_ansatz',
    'parse_hamiltonian_expression',
    'draw_final_bound_circuit',
    'print_results_summary',
    'get_theoretical_ground_state_energy',
    '__version__'
]

import logging
logging.getLogger(__name__).addHandler(logging.NullHandler())